﻿namespace Maze_Runner
{
    partial class Mazeoption
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            button1 = new Button();
            button2 = new Button();
            backgroundWorker1 = new System.ComponentModel.BackgroundWorker();
            groupBox1 = new GroupBox();
            button3 = new Button();
            checkBox2 = new CheckBox();
            checkBox1 = new CheckBox();
            groupBox2 = new GroupBox();
            button4 = new Button();
            checkBox6 = new CheckBox();
            checkBox5 = new CheckBox();
            checkBox4 = new CheckBox();
            checkBox3 = new CheckBox();
            groupBox3 = new GroupBox();
            button5 = new Button();
            checkBox8 = new CheckBox();
            checkBox7 = new CheckBox();
            groupBox6 = new GroupBox();
            button9 = new Button();
            button8 = new Button();
            button7 = new Button();
            button6 = new Button();
            groupBox5 = new GroupBox();
            button11 = new Button();
            button10 = new Button();
            trackBar1 = new TrackBar();
            groupBox1.SuspendLayout();
            groupBox2.SuspendLayout();
            groupBox3.SuspendLayout();
            groupBox6.SuspendLayout();
            groupBox5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)trackBar1).BeginInit();
            SuspendLayout();
            // 
            // button1
            // 
            button1.FlatAppearance.BorderColor = Color.Black;
            button1.FlatAppearance.MouseDownBackColor = SystemColors.Control;
            button1.FlatStyle = FlatStyle.Flat;
            button1.Font = new Font("Segoe UI", 18F, FontStyle.Regular, GraphicsUnit.Point, 162);
            button1.ForeColor = Color.FromArgb(0, 192, 0);
            button1.Location = new Point(50, 737);
            button1.Margin = new Padding(6);
            button1.Name = "button1";
            button1.Size = new Size(175, 75);
            button1.TabIndex = 0;
            button1.Text = "<--- Back";
            button1.UseVisualStyleBackColor = false;
            button1.Click += Geri;
            // 
            // button2
            // 
            button2.BackColor = Color.Black;
            button2.FlatAppearance.BorderColor = Color.Black;
            button2.FlatAppearance.MouseDownBackColor = Color.Black;
            button2.FlatStyle = FlatStyle.Flat;
            button2.Font = new Font("Segoe UI", 18F, FontStyle.Regular, GraphicsUnit.Point, 162);
            button2.ForeColor = Color.FromArgb(0, 192, 0);
            button2.Location = new Point(975, 737);
            button2.Margin = new Padding(6);
            button2.Name = "button2";
            button2.Size = new Size(175, 75);
            button2.TabIndex = 1;
            button2.Text = "Start --->";
            button2.UseVisualStyleBackColor = false;
            button2.Click += Basla;
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(button3);
            groupBox1.Controls.Add(checkBox2);
            groupBox1.Controls.Add(checkBox1);
            groupBox1.ForeColor = Color.FromArgb(0, 192, 0);
            groupBox1.Location = new Point(20, 24);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(1162, 100);
            groupBox1.TabIndex = 2;
            groupBox1.TabStop = false;
            groupBox1.Text = "Lav algoritması";
            // 
            // button3
            // 
            button3.BackColor = Color.Black;
            button3.FlatAppearance.BorderColor = Color.Black;
            button3.FlatAppearance.MouseDownBackColor = Color.Black;
            button3.FlatStyle = FlatStyle.Flat;
            button3.Location = new Point(1022, 34);
            button3.Name = "button3";
            button3.Size = new Size(99, 44);
            button3.TabIndex = 2;
            button3.Text = "0";
            button3.UseVisualStyleBackColor = false;
            // 
            // checkBox2
            // 
            checkBox2.AutoSize = true;
            checkBox2.Location = new Point(101, 50);
            checkBox2.Name = "checkBox2";
            checkBox2.Size = new Size(68, 34);
            checkBox2.TabIndex = 0;
            checkBox2.Text = "DFS";
            checkBox2.UseVisualStyleBackColor = true;
            checkBox2.CheckedChanged += checkBox2_CheckedChanged;
            // 
            // checkBox1
            // 
            checkBox1.AutoSize = true;
            checkBox1.Location = new Point(312, 50);
            checkBox1.Name = "checkBox1";
            checkBox1.Size = new Size(65, 34);
            checkBox1.TabIndex = 1;
            checkBox1.Text = "BFS";
            checkBox1.UseVisualStyleBackColor = true;
            checkBox1.CheckedChanged += checkBox1_CheckedChanged;
            // 
            // groupBox2
            // 
            groupBox2.Controls.Add(button4);
            groupBox2.Controls.Add(checkBox6);
            groupBox2.Controls.Add(checkBox5);
            groupBox2.Controls.Add(checkBox4);
            groupBox2.Controls.Add(checkBox3);
            groupBox2.ForeColor = Color.FromArgb(0, 192, 0);
            groupBox2.Location = new Point(20, 140);
            groupBox2.Name = "groupBox2";
            groupBox2.Size = new Size(1162, 100);
            groupBox2.TabIndex = 3;
            groupBox2.TabStop = false;
            groupBox2.Text = "Lav Hızı ";
            // 
            // button4
            // 
            button4.BackColor = Color.Black;
            button4.FlatAppearance.BorderColor = Color.Black;
            button4.FlatAppearance.MouseDownBackColor = Color.Black;
            button4.FlatStyle = FlatStyle.Flat;
            button4.Location = new Point(1022, 34);
            button4.Name = "button4";
            button4.Size = new Size(99, 44);
            button4.TabIndex = 4;
            button4.Text = "0";
            button4.UseVisualStyleBackColor = true;
            // 
            // checkBox6
            // 
            checkBox6.AutoSize = true;
            checkBox6.Location = new Point(101, 50);
            checkBox6.Name = "checkBox6";
            checkBox6.Size = new Size(44, 34);
            checkBox6.TabIndex = 0;
            checkBox6.Text = "X";
            checkBox6.UseVisualStyleBackColor = true;
            checkBox6.CheckedChanged += checkBox6_CheckedChanged;
            // 
            // checkBox5
            // 
            checkBox5.AutoSize = true;
            checkBox5.Location = new Point(523, 52);
            checkBox5.Name = "checkBox5";
            checkBox5.Size = new Size(55, 34);
            checkBox5.TabIndex = 2;
            checkBox5.Text = "3X";
            checkBox5.UseVisualStyleBackColor = true;
            checkBox5.CheckedChanged += checkBox5_CheckedChanged;
            // 
            // checkBox4
            // 
            checkBox4.AutoSize = true;
            checkBox4.Location = new Point(312, 50);
            checkBox4.Name = "checkBox4";
            checkBox4.Size = new Size(55, 34);
            checkBox4.TabIndex = 1;
            checkBox4.Text = "2X";
            checkBox4.UseVisualStyleBackColor = true;
            checkBox4.CheckedChanged += checkBox4_CheckedChanged;
            // 
            // checkBox3
            // 
            checkBox3.AutoSize = true;
            checkBox3.Location = new Point(709, 50);
            checkBox3.Name = "checkBox3";
            checkBox3.Size = new Size(55, 34);
            checkBox3.TabIndex = 3;
            checkBox3.Text = "4X";
            checkBox3.UseVisualStyleBackColor = true;
            checkBox3.CheckedChanged += checkBox3_CheckedChanged;
            // 
            // groupBox3
            // 
            groupBox3.Controls.Add(button5);
            groupBox3.Controls.Add(checkBox8);
            groupBox3.Controls.Add(checkBox7);
            groupBox3.ForeColor = Color.FromArgb(0, 192, 0);
            groupBox3.Location = new Point(20, 261);
            groupBox3.Name = "groupBox3";
            groupBox3.Size = new Size(1162, 100);
            groupBox3.TabIndex = 4;
            groupBox3.TabStop = false;
            groupBox3.Text = "Labirent ";
            // 
            // button5
            // 
            button5.BackColor = Color.Black;
            button5.FlatAppearance.BorderColor = Color.Black;
            button5.FlatAppearance.MouseDownBackColor = Color.Black;
            button5.FlatStyle = FlatStyle.Flat;
            button5.Location = new Point(1022, 34);
            button5.Name = "button5";
            button5.Size = new Size(99, 44);
            button5.TabIndex = 3;
            button5.Text = "0";
            button5.UseVisualStyleBackColor = true;
            // 
            // checkBox8
            // 
            checkBox8.AutoSize = true;
            checkBox8.Location = new Point(101, 44);
            checkBox8.Name = "checkBox8";
            checkBox8.Size = new Size(100, 34);
            checkBox8.TabIndex = 0;
            checkBox8.Text = "Maze 1";
            checkBox8.UseVisualStyleBackColor = true;
            checkBox8.CheckedChanged += checkBox8_CheckedChanged;
            // 
            // checkBox7
            // 
            checkBox7.AutoSize = true;
            checkBox7.Location = new Point(312, 44);
            checkBox7.Name = "checkBox7";
            checkBox7.Size = new Size(100, 34);
            checkBox7.TabIndex = 1;
            checkBox7.Text = "Maze 2";
            checkBox7.UseVisualStyleBackColor = true;
            checkBox7.CheckedChanged += checkBox7_CheckedChanged;
            // 
            // groupBox6
            // 
            groupBox6.Controls.Add(button9);
            groupBox6.Controls.Add(button8);
            groupBox6.Controls.Add(button7);
            groupBox6.Controls.Add(button6);
            groupBox6.Location = new Point(729, 517);
            groupBox6.Name = "groupBox6";
            groupBox6.Size = new Size(453, 179);
            groupBox6.TabIndex = 7;
            groupBox6.TabStop = false;
            // 
            // button9
            // 
            button9.BackColor = Color.Black;
            button9.FlatAppearance.BorderColor = Color.Black;
            button9.FlatAppearance.MouseDownBackColor = Color.Black;
            button9.FlatStyle = FlatStyle.Flat;
            button9.Location = new Point(281, 34);
            button9.Name = "button9";
            button9.Size = new Size(152, 132);
            button9.TabIndex = 3;
            button9.Text = "button9";
            button9.UseVisualStyleBackColor = true;
            // 
            // button8
            // 
            button8.BackColor = Color.Black;
            button8.FlatAppearance.BorderColor = Color.Black;
            button8.FlatAppearance.MouseDownBackColor = Color.Black;
            button8.FlatStyle = FlatStyle.Flat;
            button8.Location = new Point(16, 126);
            button8.Name = "button8";
            button8.Size = new Size(259, 40);
            button8.TabIndex = 2;
            button8.Text = "button8";
            button8.UseVisualStyleBackColor = true;
            // 
            // button7
            // 
            button7.BackColor = Color.Black;
            button7.FlatAppearance.BorderColor = Color.Black;
            button7.FlatAppearance.MouseDownBackColor = Color.Black;
            button7.FlatStyle = FlatStyle.Flat;
            button7.Location = new Point(16, 80);
            button7.Name = "button7";
            button7.Size = new Size(259, 40);
            button7.TabIndex = 1;
            button7.Text = "button7";
            button7.UseVisualStyleBackColor = true;
            // 
            // button6
            // 
            button6.BackColor = Color.Black;
            button6.FlatAppearance.BorderColor = Color.Black;
            button6.FlatAppearance.MouseDownBackColor = Color.Black;
            button6.FlatStyle = FlatStyle.Flat;
            button6.Location = new Point(16, 34);
            button6.Name = "button6";
            button6.Size = new Size(259, 40);
            button6.TabIndex = 0;
            button6.Text = "button6";
            button6.UseVisualStyleBackColor = true;
            // 
            // groupBox5
            // 
            groupBox5.Controls.Add(button11);
            groupBox5.Controls.Add(button10);
            groupBox5.Controls.Add(trackBar1);
            groupBox5.ForeColor = Color.FromArgb(0, 192, 0);
            groupBox5.Location = new Point(20, 517);
            groupBox5.Name = "groupBox5";
            groupBox5.Size = new Size(412, 137);
            groupBox5.TabIndex = 8;
            groupBox5.TabStop = false;
            groupBox5.Text = "Ses";
            // 
            // button11
            // 
            button11.BackColor = Color.Black;
            button11.FlatAppearance.BorderColor = Color.Black;
            button11.FlatAppearance.MouseDownBackColor = Color.Black;
            button11.FlatStyle = FlatStyle.Flat;
            button11.Location = new Point(211, 85);
            button11.Name = "button11";
            button11.Size = new Size(115, 39);
            button11.TabIndex = 2;
            button11.Text = "Ses 2";
            button11.UseVisualStyleBackColor = true;
            button11.Click += button11_Click;
            // 
            // button10
            // 
            button10.BackColor = Color.Black;
            button10.FlatAppearance.BorderColor = Color.Black;
            button10.FlatAppearance.MouseDownBackColor = Color.Black;
            button10.FlatStyle = FlatStyle.Flat;
            button10.Location = new Point(63, 85);
            button10.Name = "button10";
            button10.Size = new Size(115, 39);
            button10.TabIndex = 1;
            button10.Text = "Ses 1";
            button10.UseVisualStyleBackColor = true;
            button10.Click += Ses_sec;
            // 
            // trackBar1
            // 
            trackBar1.Location = new Point(39, 34);
            trackBar1.Maximum = 100;
            trackBar1.Name = "trackBar1";
            trackBar1.Size = new Size(347, 45);
            trackBar1.TabIndex = 0;
            trackBar1.Value = 50;
            // 
            // Mazeoption
            // 
            AutoScaleDimensions = new SizeF(12F, 30F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.ActiveCaptionText;
            ClientSize = new Size(1200, 850);
            Controls.Add(groupBox5);
            Controls.Add(groupBox6);
            Controls.Add(groupBox3);
            Controls.Add(groupBox2);
            Controls.Add(groupBox1);
            Controls.Add(button2);
            Controls.Add(button1);
            Font = new Font("Segoe UI", 15.75F, FontStyle.Regular, GraphicsUnit.Point, 162);
            ForeColor = Color.FromArgb(0, 192, 0);
            FormBorderStyle = FormBorderStyle.None;
            Margin = new Padding(6);
            Name = "Mazeoption";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "MazeRunner";
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            groupBox2.ResumeLayout(false);
            groupBox2.PerformLayout();
            groupBox3.ResumeLayout(false);
            groupBox3.PerformLayout();
            groupBox6.ResumeLayout(false);
            groupBox5.ResumeLayout(false);
            groupBox5.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)trackBar1).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private Button button1;
        private Button button2;
        private System.ComponentModel.BackgroundWorker backgroundWorker1;
        private GroupBox groupBox1;
        private GroupBox groupBox2;
        private GroupBox groupBox3;
        private GroupBox groupBox6;
        private CheckBox checkBox2;
        private CheckBox checkBox1;
        private CheckBox checkBox6;
        private CheckBox checkBox5;
        private CheckBox checkBox4;
        private CheckBox checkBox3;
        private CheckBox checkBox8;
        private CheckBox checkBox7;
        private Button button3;
        private Button button4;
        private Button button5;
        private GroupBox groupBox5;
        private TrackBar trackBar1;
        private Button button9;
        private Button button8;
        private Button button7;
        private Button button6;
        private Button button11;
        private Button button10;
    }
}