﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Maze_Runner
{
    public partial class Giriş : Form
    {
        string path = "Kullanıcılar.txt";  // kullanıcılar.txt dosyasının yolu 
        public Giriş()
        {
            InitializeComponent();
        }

        private void Geri(object sender, EventArgs e)  // geri butonunun tıklama  eventi 
        {
            this.Close();
        }

        private void Login(object sender, EventArgs e)  // Girilen değerlerin goğruluğunu kontrol eden metot 
        {
             if (Kullanıcı_ara(textBox1.Text))  // kullanıcı_ara metotu ile kullanıcılar.txt dosyasında arama yapılır 
             {
                if (Sifre_dogrulama(textBox2.Text)) // sifre_dogrulama ile kullanıcılar.txt dosyasında sorgu yapılır 
                { 
                    MessageBox.Show("Başarılı Giriş");  // başarılı giriş 
                    Mazeoption option = new Mazeoption(textBox1.Text);  // mazeoption formu oluşturulur , parametre olarak kullanıcı ismi verilir 
                    option.FormClosing += Mazeoption_FormClosing;  
                    option.Show();
                    this.Hide();
                }
                else
                {
                    MessageBox.Show("Şifre Yanlış");  // hata mesajı 
                }
            }
            else
            {
                MessageBox.Show("Kullanıcı Yok"); // hata mesajı 
            }
        }
        private void Mazeoption_FormClosing(object sender, FormClosingEventArgs e)   // mazeoptionun formunun kapatma olayı 
        {
            this.Close();
        }
        public bool Kullanıcı_ara(string a)  // kullanıcı ara metotu 
        {
            string satır;
            using (StreamReader sr = new StreamReader(path))   // kullanıcılar.txt dosyasında okuma nesnesi oluşturma 
            {
                while ((satır = sr.ReadLine()) != null)  //satırları gezme 
                {
                    char[] chars1 = satır.ToCharArray();   // satırlar  char dizisi haline getirilir ve arama yapılır 
                    for (int i = 0; i < chars1.Length; i++)  // char  dizisindegezilmeye başlanır 
                    {
                        if (chars1[i] == '@')    // ilk ed işaretine kadar okunur 
                        {
                            char[] temp = new char[i];  // ilk ed işaratine kadar olan karaketerler yeni diziye aktarılır 
                            for (int j = 0; j < i; j++)
                            {
                                temp[j] = chars1[j];
                            }

                            if (My_tostring(temp) == a)  // yeni oluşturulan dizi string haline getirilir ve girilen kullanıcıyla eşleşme var mı bakılır 
                            {
                                return true;
                            }
                            break;
                        }
                    }
                }
            }
            return false;
        }
        public bool Sifre_dogrulama(string a)  // sifre doğrulama metotu 
        {
            string satır;
            using (StreamReader sr = new StreamReader(path)) // okuma nesnesi 
            {
                while ((satır = sr.ReadLine()) != null)  // satırları okuma 
                {
                    int sayac = 0;  
                    List<char> sifre = new List<char>();  
                    bool flag = false;
                    char[] chars1 = satır.ToCharArray();
                    for (int i = 0; i < chars1.Length; i++)
                    {
                        if (chars1[i] == '@')
                        {
                            sayac += 1;
                            flag = true;
                            continue;
                        }

                        if (sayac > 1)
                        {
                            break;
                        }
                        else if (flag)
                        {
                            sifre.Add(chars1[i]);
                        }
                    }
                    if (a == My_tostring_list(sifre))
                    {
                        return true;
                    }
                }
            }
            return false;
        }
        public string My_tostring(char[] chars)  // my_tostring metotumuz 
        {
            string a = "";
            for (int i = 0; i < chars.Length; i++)
            {
                a = a + chars[i];
            }
            return a;
        }
        public string My_tostring_list(List<char> chars)//my_tostring_list  metotumuz 
        {
            string a = "";
            for (int i = 0; i < chars.Count; i++)
            {
                a = a + chars[i];
            }
            return a;
        }
    }
}
