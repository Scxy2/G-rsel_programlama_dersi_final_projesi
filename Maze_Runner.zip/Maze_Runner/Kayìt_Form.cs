﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Runtime.CompilerServices;

namespace Maze_Runner
{
    public partial class Kayıt_Form : Form
    {
        public string path = "Kullanıcılar.txt";   //kullanıcılar.txt dosyasına erişmek için yol tanımlıyoruz
        public Kayıt_Form()
        {
            InitializeComponent();
        }
        private void Geri(object sender, EventArgs e)  // geri butonunun tıklanma eventi 
        {
            this.Close();
        }

        private async void Kayit_ol(object sender, EventArgs e)  // kayıt  ol butonunun tıklanme eventi 
        {
            if (textBox1.Text.Length > 50)                  //kullanıcı string kontrol 
            {
                MessageBox.Show("Kullanıcı adını lütfen 1-50 arasında bir string girin");
            }
            else if (textBox2.Text.Length > 50)             //şifre string kontrol 
            {
                MessageBox.Show("Kullanıcı adını lütfen 6-20 arasında bir string girin");
            }
            else if (Ara(textBox1.Text))        // ara metotu ile var olan kullanıcı girişi kontrolu
            {
                MessageBox.Show("Kullanıcı Kullanımda");
            }
            else if (textBox2.Text != textBox3.Text)   // girilen şifrelerin eş mi kontrolu 
            {
                MessageBox.Show("Şifreler eşleşmiyor");
            }
            else if (textBox1.Text == null)   // hiç bir şey girilemezse 
            {
                MessageBox.Show("Hatalı girdi");
            }
            else if (textBox2.Text == null)  // hiç bir şey girilemezse 
            {
                MessageBox.Show("Hatalı girdi");
            }
            else if (textBox3.Text == null)  // hiç bir şey girilemezse 
            {
                MessageBox.Show("Hatalı girdi");
            }
            else
            {
                try
                {
                    string kisi = textBox1.Text + "@" + textBox2.Text + "@" + "\n";     // tüm yukardaki koşullar geçilince  kayıt .txt dosyasına kayıt yapan kod satırı 
                    File.AppendAllText(path, kisi);    
                    MessageBox.Show("Başarılı kayıt!!!");  // başarılı kayıy mesajı                 //kullanıcı_adı@şifre@   kayıt olunur 

                }
                catch (Exception ex)         //hata bloğu dosya açılamaz veya diğer hatalar oluştuğunda 
                {
                    MessageBox.Show("Kayıt Başarısız----->" + ex.Message);
                    this.Close();
                }           
                this.Close();  // form kapatılır 
            }
        }
        public bool Ara(string a)   // Yukarda kullanılan ara metotu , kullanıcılar.txt satır satır okur, text butonuna girilen değeri ilgili kısımlarda karşılaştırtır , eşleşme varsa  true döndürür 
        {
            string satır;
            using (StreamReader sr = new StreamReader(path))     // dosyayı okumak için streamreader nesnesi 
            {
                while ((satır = sr.ReadLine()) != null)   //bütün satırları gezen blok 
                {
                    char[] chars1 = satır.ToCharArray();
                    for (int i = 0; i < chars1.Length; i++)      
                    {                                          
                        if (chars1[i] == '@')              
                        {
                            char[] temp = new char[i];
                            for (int j = 0; j < i; j++)          //
                            {                                    // gerekli algoritmik kodlar 
                                temp[j] = chars1[j];             //
                            }
                            if (My_tostring(temp) == a)
                            {
                                return true;
                            }
                            break;
                        }
                    }
                }
            }
            return false;
        }
        public string My_tostring(char[] chars)  // kendi tostring metotumuz 
        {
            string a = "";
            for (int i = 0; i < chars.Length; i++)
            {
                a += chars[i];
            }
            return a;
        }
    }
}
