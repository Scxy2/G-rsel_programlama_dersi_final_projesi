﻿using Microsoft.VisualBasic.ApplicationServices;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics.SymbolStore;
using System.Drawing;
using System.Linq;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.ConstrainedExecution;
using System.Runtime.InteropServices;
using System.Security;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Timers;
using static System.Net.Mime.MediaTypeNames;
using static System.Windows.Forms.DataFormats;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.Tab;
using NAudio;
using NAudio.Wave;
using System.IO;
using System.Diagnostics.Metrics;
namespace Maze_Runner
{
    public partial class Maze : Form
    {
        public string kullanıcı;   
        public IWavePlayer waveOut;
        public AudioFileReader audioFileReader;
        public string Lav_sesi;                                //
        public int ses_duzeyi;                                 // Gerekli değişkenler 
        private readonly Karakter_picturebox adam;             //
        private int delay;
        public int algoritma;
        public int Kat_sayı;
        int[] Lav_Konum = { 0, 1 };
        int[,] kopya_maze1_matris = (int[,])Labirentler.maze1.Clone();
        int[,] kopya_maze2_matris = (int[,])Labirentler.maze1.Clone();
        public Maze(int algoritma, int delay, int kat_sayı, int ses, string Lav_sesi_yol, string klc)  // (Buradaki parametreler Mazeoption oluşturuken checkboxlardaan verilir)
        {
            this.algoritma = algoritma;
            this.delay = delay;
            this.KeyPreview = true;
            this.Kat_sayı = kat_sayı;
            InitializeComponent();
            this.kullanıcı = klc;
            adam = new Karakter_picturebox(kopya_maze2_matris, kat_sayı, this.button3, this.Lav_Konum, this.button2, this.checkBox1, kullanıcı, checkBox2);  // Karaketer nesnemiz 
            Kat_sayı = kat_sayı;
            ses_duzeyi = ses;
            Lav_sesi = Lav_sesi_yol;
            checkBox1.Checked = false;
        }
        public void Maze_Load(object sender, EventArgs e)   //mazeload metotu maze formu oluşturulduğunda Labirenti oluşturur 
        { 
            pictureBox1.Paint += new PaintEventHandler(Maze_olustur);  // Labirent çizim metotu 
            Lav_picturebox lav_ilk_konum = new Lav_picturebox(Lav_Konum[0], Lav_Konum[1]); // lav başlangıç picturebox'ı
            pictureBox1.Controls.Add(lav_ilk_konum);
            PlaySoundLooping();  // ses metotumuzu kullandık
            pictureBox1.Controls.Add(adam); // Karakterimizi picturebox controlune atama 
            this.Focus(); 
            this.KeyDown += new KeyEventHandler(Maze_KeyDown); 
            Lav_algoritma(); // Lav hareketini başlatan metot 
        }

        public void Maze_KeyDown(object sender, KeyEventArgs e)  // keydaw olayımız 
        {
            adam.MoveCharacter(e.KeyCode);   
        }
        public void Maze_olustur(object sender, PaintEventArgs e) // Labirentimzi olusturan metot 
        { 
            SolidBrush l = new SolidBrush(Color.Black);    //fırca nesnelerimiz 
            SolidBrush t = new SolidBrush(Color.Green);    //
            Pen k = new Pen(Color.Black);          // kalem nesnemiz 
            e.Graphics.FillRectangle(t, 30 * 39, 30 * 22, 30, 30); // bitiş noktamızı yeşile boyama 
            for (int i = 0; i < 25; i++)  // labirent matrisinde içi içe for ile gezinme 
            {
                for (int j = 0; j < 40; j++)
                {
                    e.Graphics.DrawRectangle(k, 30 * j, 30 * i, 30, 30);  
                    if (kopya_maze1_matris[i, j] == 1)   // matrisin değeri 1 ise duvar , 0 ise yol olarak çizilir 
                    {
                        e.Graphics.FillRectangle(l, 30 * j, 30 * i, 30, 30);
                    }
                }
            }
            l.Dispose();
            t.Dispose();
            k.Dispose();
        }
        private void PlaySoundLooping()  // Döngüsel müzik çalma metotumuz 
        {
            try
            {
                waveOut = new WaveOutEvent();
                audioFileReader = new AudioFileReader(Lav_sesi);//ses dosyasını okuma 

                waveOut.Init(audioFileReader); //waveout nesnemizi audiofilereader ile başaltılır 
                waveOut.Volume = ses_duzeyi / 100f; // ses düzeyini ayarlama 
                waveOut.Play(); // müziği başlatma 

                waveOut.PlaybackStopped += PlaybackStoppedEventHandler; // ses durduğunda tetiklenecek işleyic
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ses dosyası çalınamadı: " + ex.Message);
            }
        }


        public void Stop()  // form sayfası kapandığında müziği durdurmak içim metotumuz 
        {
            if (waveOut != null)
            {
                waveOut.PlaybackStopped -= PlaybackStoppedEventHandler;

                waveOut.Stop();
                waveOut.Dispose();
                waveOut = null;
            }

            if (audioFileReader != null)
            {
                audioFileReader.Dispose();
                audioFileReader = null;
            }
        }

        private void PlaybackStoppedEventHandler(object sender, StoppedEventArgs e) //ses durduğunda cağılacak olan metotumuz var 
        {
            if (audioFileReader != null)
            {
                audioFileReader.Position = 0;
                waveOut.Play(); // döngüsel çalma 
            }
        }

        private void Masaustu_don(object sender, EventArgs e)  // masaüstüdon metotu için tıklanme eventi 
        {
            Stop();
            MazeRunner mazeRunner = System.Windows.Forms.Application.OpenForms["MazeRunner"] as MazeRunner;   // tüm programı sonlandırır 
            if (mazeRunner != null)
            {
                mazeRunner.Close();
            }
            Mazeoption mazeOption = System.Windows.Forms.Application.OpenForms["option"] as Mazeoption;
            if (mazeOption != null)
            {
                mazeOption.Close();
            }
            this.Close();
        }

        private void Geri(object sender, EventArgs e)  // geri butonu için için tıklama eventi maze formunu kapatır 
        {
            Stop();   
            this.Close();
        }


        public void Lav_algoritma()  // cunstructer ile gelen lav algoritmasını değerini bfs mi dfs mi olduğunu belirler 
        {
            if (this.algoritma == 0)
            {
                Dfs();
            }
            else if (this.algoritma == 1)
            {
                Bfs();
            }
        }
        public async void Dfs()  // dfs algoritması 
        {
            if (kopya_maze1_matris[1, 0] == 1)   
            {
                this.Close();
            }
            else
            {
                int sayac = 0;
                Stack yıgıt = new Stack();  //  gerekli değişken tanımlamaları 
                Node baslangıc = new Node(0, 1); // 
                List<Node> komsular = Komsu_bul(baslangıc);

                foreach (Node k in komsular)
                {
                    yıgıt.Push(k);
                }
                while (yıgıt.Count() != 0)
                {
                    sayac++;                                              // dfs algoritması labirent yolunu bir graf gibi düşünür başlangıç konumundan itibaren yolun devamındaki komşu yolları komşu_bul 
                    await Task.Delay(delay);                              //metotu yardımıyla bularak bir stack yapısına atar ve sonra bu stackten pop() metotunu kullanarak bir  komşu yol çeker. 
                    komsular.Clear();                                       // çekilen komşu yolun komşularını da stack yapısına atarak bu işlem stack count 0 oluncaya kadar devam eder.stackten çekilen 
                    Node temp = yıgıt.Pop();                                //yolların konumuna lavpicturebox koyulur ve lav animasyonu sağlanır.böylece labirente dfs algoritmasıyla gezen lavımız olur.
                    if (temp.x == 39 && temp.y == 22)                       //ayrıca karakterin olduğu yere picturebox koyulmaya çalışılınca yanma mesajı döndürür ve form sayfasını kapatarak mazeoption formuna geri dönülür
                    {
                        break;
                    }
                    Lav_picturebox lavvv = new Lav_picturebox(temp.x, temp.y);
                    if (adam.Karakter_konum[0] == temp.x && adam.Karakter_konum[1] == temp.y)
                    {
                        MessageBox.Show("Lavda yüzmeye çalıştınız");
                        Stop();
                        this.Close();
                    }
                    Lav_Konum[0] = temp.x;
                    Lav_Konum[1] = temp.y;
                    pictureBox1.Controls.Add(lavvv);
                    komsular = Komsu_bul(temp);
                    foreach (Node k in komsular)
                    {
                        yıgıt.Push(k);
                    }

                }
            }
        }
        private async void Bfs()
        {
            if (kopya_maze1_matris[1, 0] == 1)
            {
                this.Close();
            }
            else                                                          //bfs algoritması aynı dfs gibi çalışır ancak stack yerine kuyruk veri yapısını kullanır 
            {
                int sayac = 0;
                Quueu kuyruk = new Quueu();
                Node baslangıc = new Node(0, 1);
                List<Node> komsular = Komsu_bul(baslangıc);

                foreach (Node k in komsular)
                {
                    kuyruk.Push(k);
                }
                while (kuyruk.Count() != 0)
                {
                    sayac++;
                    await Task.Delay(delay);
                    komsular.Clear();
                    Node temp = kuyruk.Pop();
                    if (temp.x == 39 && temp.y == 22)
                    {
                        break;
                    }
                    Lav_picturebox lavvv = new Lav_picturebox(temp.x, temp.y);
                    if (adam.Karakter_konum[0] == temp.x && adam.Karakter_konum[1] == temp.y)
                    {
                        MessageBox.Show("Lavda yüzmeye çalıştınız");
                        Stop();
                        this.Close();
                    }
                    Lav_Konum[0] = temp.x;
                    Lav_Konum[1] = temp.y;
                    pictureBox1.Controls.Add(lavvv);
                    komsular = Komsu_bul(temp);
                    foreach (Node k in komsular)
                    {
                        kuyruk.Push(k);
                    }
                }
            }
        }
        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        public class Lav_picturebox : PictureBox                    // Lav picture box ımız var 
        {
            private string[] Lavlar = { "lav1.png", "lav2.png", "lav3.png", "lav4.png", "lav5.png", "lav6.png", "lav7.png", "lav8.png" };  // lav resimlerinin dizinleri 
            private int index = 0;
            private int en = 30;
            private int boy = 30;
            private System.Windows.Forms.Timer timer1;    // timer nesnemiz 
            private System.Drawing.Image[] Lavlar1;

            public Lav_picturebox(int x, int y)
            {
                timer1 = new System.Windows.Forms.Timer();
                timer1.Interval = 100;
                timer1.Tick += Timer1_Tick;
                Bounds = new Rectangle(x * 30, y * 30, 30, 30);
                LoadImages();
                timer1.Start();
            }

            private void LoadImages()   // resimleri yükleme 
            {
                Lavlar1 = new System.Drawing.Image[Lavlar.Length];
                for (int i = 0; i < Lavlar.Length; i++)
                {
                    string imagePath = @"Lav_animation\" + Lavlar[i];
                    System.Drawing.Image img = System.Drawing.Image.FromFile(imagePath);
                    Lavlar1[i] = new Bitmap(img, en, boy);
                }
                Image = Lavlar1[index];
                SizeMode = PictureBoxSizeMode.StretchImage;
                Refresh();
            }

            private void Timer1_Tick(object sender, EventArgs e)  //timet tetiklenme metotu 
            {
                ChangeBackgroundImage();
                timer1.Start();

            }
            private void ChangeBackgroundImage()  // pictureboxun resmini değiştiren metot 
            {
                index = (index + 1) % Lavlar.Length;
                Image = Lavlar1[index];
                Refresh();
            }
        }
        public List<Node> Komsu_bul(Node a)  // komşu bul metotumuz , bu metot labiretten bir yol kutucuğu alarak ona komşu alan yol kutukçukalrını döndürür 
        {
            List<Node> list = new List<Node>();
            kopya_maze1_matris[a.y, a.x] = 1;

            if (a.y - 1 > 0)
            {
                if (kopya_maze1_matris[a.y - 1, a.x] == 0)
                {
                    kopya_maze1_matris[a.y - 1, a.x] = 1;
                    Node komsu_ust = new Node(a.x, a.y - 1);
                    list.Add(komsu_ust);
                }
            }

            if (a.x + 1 <= 39)
            {
                if (kopya_maze1_matris[a.y, a.x + 1] == 0)
                {
                    kopya_maze1_matris[a.y, a.x + 1] = 1;
                    Node komsu_sag = new Node(a.x + 1, a.y);
                    list.Add((komsu_sag));                                       //
                }                                                               //gerekli algoritmalar 
            }                                                                   //
                                                                                //kısacası parametre olarak girilen  yol kutuçuğuna uzaklığı 1 olan kutucukların değerlerine bakar , 0 ise döndürülecek olan 
            if (a.y + 1 < 24)                                                    //  node dizinine  ekler                            
            {
                if (kopya_maze1_matris[a.y + 1, a.x] == 0)
                {
                    kopya_maze1_matris[a.y + 1, a.x] = 1;
                    Node komsu_alt = new Node(a.x, a.y + 1);
                    list.Add((komsu_alt));
                }
            }

            if (a.x - 1 > 0)
            {
                if (kopya_maze1_matris[a.y, a.x - 1] == 0)
                {
                    kopya_maze1_matris[a.y, a.x - 1] = 1;
                    Node komsu_sol = new Node(a.x - 1, a.y);
                    list.Add((komsu_sol));
                }
            }

            return list;
        }
        public bool Kontrol(int[] lav, int[] karakter)                           //lav konumu ve karakter konumunun aynı olup olmadığını kontrol eder 
        {
            if (lav[0] == karakter[0] && lav[1] == karakter[1])
            {
                return true;
            }
            return false;
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)  
        {
            if (checkBox1.Checked == true)
            {
                this.Close();
            }
        }

        private void checkBox2_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox2.Checked == true)
            {
                Stop();
            }
        }
    }

    ///////////////////////////////////////////////////////////////////////////D//////////////////////////////////////////////////////////////////////
    //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    class Karakter_picturebox : PictureBox    // karakter nesnemiz 
    {
        public System.Windows.Forms.Button asd;
        public System.Windows.Forms.CheckBox dsa;   
        public System.Windows.Forms.CheckBox qaz;
        public string kullanıcı;
        public int Puan=0; 
        public int index = 5;  
        public int[] Karakter_konum = { 2, 1 };  // x , y   x yatay y düşey konum 
        public int[,] maze1;
        public int[] Lav_konum;
        public int Kat_sayi;
        public string[] div_yol = { "W_walk", "A_walk", "S_walk", "D_walk" };
        public string[] w_yol = { "w1", "w2", "w3", "w4", "w5", "w6", "w7", "w8", "w9", "w10" };       // yürüme resimlerinin  dizinlerini tutan değişkenler 
        public string[] a_yol = { "a1", "a2", "a3", "a4", "a5", "a6", "a7", "a8", "a9", "a10" };
        public string[] s_yol = { "s1", "s2", "s3", "s4", "s5", "s6", "s7", "s8", "s9", "s10" };
        public string[] d_yol = { "d1", "d2", "d3", "d4", "d5", "d6", "d7", "d8", "d9", "d10" };
        public System.Drawing.Image[,] walk = new System.Drawing.Image[4,10];
        public System.Drawing.Image[] w_har = new System.Drawing.Image[10];
        public System.Drawing.Image[] a_har = new System.Drawing.Image[10];            // gerekli değişkenler 
        public System.Drawing.Image[] s_har = new System.Drawing.Image[10];
        public System.Drawing.Image[] d_har = new System.Drawing.Image[10]; 
        public Karakter_picturebox(int[,] a, int kat_sayi ,System.Windows.Forms.Button asd1, int[] b,System.Windows.Forms.Button dsa1 , System.Windows.Forms.CheckBox cl,string klc, System.Windows.Forms.CheckBox st)
        {
            Image_load();  // resim dizinlerini programa yükler 
            maze1 = a;
            Bounds = new Rectangle(Karakter_konum[0] * 30, Karakter_konum[1] * 30, 30, 30);
            Image = d_har[5];
            Kat_sayi = kat_sayi;                          //gerekli tanımlamalar 
            asd = asd1;
            dsa = cl;
            Lav_konum = b;
            kullanıcı = klc;
            qaz = st;
        }
        public void Image_load()    // kısaca bu metot yukarda tanımlanmış resim yollarını değişkenler atar 

        {
            for (int i = 0; i < div_yol.Length; i++)
            {
                for (int j = 0; j < w_yol.Length; j++)
                {
                    if (i == 0)
                    {
                        string a = div_yol[i] + "/" + w_yol[j] + ".jpg";
                        System.Drawing.Image img = System.Drawing.Image.FromFile(a);
                        w_har[j] = new Bitmap(img, 30, 30);
                        walk[i,j]= new Bitmap(img, 30, 30);
                    }
                    else if (i == 1)
                    {
                        string a = div_yol[i] + "/" + a_yol[j] + ".jpg";
                        System.Drawing.Image img = System.Drawing.Image.FromFile(a);
                        a_har[j] = new Bitmap(img, 30, 30);
                        walk[i, j] = new Bitmap(img, 30, 30);
                    }
                    else if (i == 2)
                    {
                        string a = div_yol[i] + "/" + s_yol[j] + ".jpg";
                        System.Drawing.Image img = System.Drawing.Image.FromFile(a);
                        s_har[j] = new Bitmap(img, 30, 30);
                        walk[i, j] = new Bitmap(img, 30, 30);
                    }
                    else if (i == 3)
                    {
                        string a = div_yol[i] + "/" + d_yol[j] + ".jpg";
                        System.Drawing.Image img = System.Drawing.Image.FromFile(a);
                        d_har[j] = new Bitmap(img, 30, 30);
                        walk[i, j] = new Bitmap(img, 30, 30);
                    }
                }
            }
            Image = d_har[index];
            SizeMode = PictureBoxSizeMode.StretchImage;
            Refresh();
        }
        public void MoveCharacter(Keys key)  // bu haraket metotumuz - gelen key değişkenene bakarak yürümeyi ve  yürüme efektlerini sağlar 
        {
            switch (key)
            {
                case Keys.W:
                    if (Haraket_kontrol_w())
                    {
                        Walk_animation(0); 
                    }
                    break;
                case Keys.A:
                    if (Haraket_kontrol_a())
                    {
                        Walk_animation(1);
                    }
                    break;
                case Keys.S:
                    if (Haraket_kontrol_s())
                    {

                        Walk_animation(2);
                    }
                    break;
                case Keys.D:
                    if (Haraket_kontrol_d())
                    {
                        Walk_animation(3);
                    }
                    break;
            }
            Location = new Point(Karakter_konum[0]*30, Karakter_konum[1] * 30);
            Refresh();          
        }

        public async void Walk_animation(int k) {     // yürüme efekti gelen key değerine göre karakter picture boxu 1px haraket ettirir ve her hareket ettirildiğine arka plan resmi değiştirilir. 
            int a = Karakter_konum[0];  
            int b = Karakter_konum[1];
            switch (k)
            {
                case 0:
                    Puan = Puan + Kat_sayi;
                    Puan_guncelleme(Puan);
                    if (Lav_konum[0] == Karakter_konum[0] && Lav_konum[1] == Karakter_konum[1])
                    {
                        MessageBox.Show("Lavda yüzmeye çalıştınız");
                        qaz.Checked = true;
                    }
                    Karakter_konum[1] -= 1;
                    for(int i = 1; i <= 30; i++)
                    {
                        await Task.Delay(1);
                        Image = walk[0, (index + i) % 10];
                        Location = new Point(a * 30, b * 30-i);
                        Refresh();
                    } 
                    break;
                case 1:
                    Puan = Puan + Kat_sayi;
                    if (Lav_konum[0] == Karakter_konum[0] && Lav_konum[1] == Karakter_konum[1])
                    {
                        MessageBox.Show("Lavda yüzmeye çalıştınız");
                        qaz.Checked = true;
                    }
                    Puan_guncelleme(Puan);
                    Karakter_konum[0] -= 1;
                    for (int i = 1; i <= 30; i ++)
                    {
                        await Task.Delay(1);
                        Image = walk[1, (index + i) % 10];
                        Location = new Point(a * 30-i, b * 30);
                        Refresh();
                    }
                    break;
                case 2:
                    Puan = Puan + Kat_sayi;
                    if (Lav_konum[0] == Karakter_konum[0] && Lav_konum[1] == Karakter_konum[1])
                    {
                        MessageBox.Show("Lavda yüzmeye çalıştınız");
                        qaz.Checked = true;
                    }
                    Puan_guncelleme(Puan);
                    Karakter_konum[1] += 1;
                    for (int i = 1; i <= 30; i++)
                    {
                        await Task.Delay(1);
                        Image = walk[2, (index + i) % 10];
                        Location = new Point(a* 30, b * 30+i);
                        Refresh();
                    }
                    break;
                case 3:
                    Puan = Puan + Kat_sayi;
                    if (Lav_konum[0] == Karakter_konum[0] && Lav_konum[1] == Karakter_konum[1])
                    {
                        MessageBox.Show("Lavda yüzmeye çalıştınız");
                        qaz.Checked= true;
                    }
                    Puan_guncelleme(Puan);
                    Karakter_konum[0] += 1;
                    for (int i = 1; i <= 30; i++)
                    {
                        await Task.Delay(1);
                        Image = walk[3,(index+i)%10];
                        Location = new Point(a * 30 + i , b * 30);
                        Refresh();
                    }
                    break;
            }
        }
        public void Puan_guncelleme(int a)    // puan güncelleme her kare başına puanı hesaplar 
        {
            asd.Text = $"{a}";
        }
        public bool Haraket_kontrol_w()   // haraket kontrolu yani ilgili yöne karakter haraket edebilir mi onu kontrol eder  . edebiliyosa true döndürür 
        {
            if (maze1[Karakter_konum[1]-1,Karakter_konum[0]] == 0)
            {
                return true;    
            }
            return false;
        }
        public bool Haraket_kontrol_a()
        {
            if (maze1[Karakter_konum[1], Karakter_konum[0]-1] == 0)
            {
                return true;
            }
            return false;
        }
        public bool Haraket_kontrol_s()
        {
            if (maze1[Karakter_konum[1]+1, Karakter_konum[0] ] == 0)
            {
                return true;
            }
            return false;
        }
        public bool Haraket_kontrol_d()  
        {
            try
            {
                if (maze1[Karakter_konum[1], Karakter_konum[0] + 1] == 0)
                {

                    return true;
                }
                return false;
            }catch (Exception e)
            {
                MessageBox.Show("Tebrikler Labirentten kaçtınız");
                qaz.Checked = true;
                Puan_kayıt(asd.Text,kullanıcı);
                dsa.Checked = true;
                return false ;
            }
        }
        public static void Puan_kayıt(string a,string kullanıcı)  // puan kayıt  metotu bu metot kullancılar.txt dosyasında kullanıcının puanının kayıt eder 
        {                                                                   // aldığı puan var olan puandan düşükse puanı değişmez 
            string path = "Kullanıcılar.txt";
            string geciciDosyaYolu = path + ".tmp";
            try
            {
                using (var sr = new StreamReader(path))
                using (var sw = new StreamWriter(geciciDosyaYolu))
                {
                    string satir;
                    while ((satir = sr.ReadLine()) != null)
                    {
                        string[] parcalar = satir.Split('@');
                        if (parcalar[2].Length>3 &&kullanıcı == parcalar[0])
                        {
                            if (int.Parse(parcalar[2]) <= int.Parse(a)){
                                satir = parcalar[0] + "@" + parcalar[1] + "@"+ a;
                            }
                            else
                            {
                                satir = parcalar[0] + "@" + parcalar[1] + "@" + parcalar[2];
                            }
                        }
                        else if(kullanıcı == parcalar[0]){
                            satir = parcalar[0] + "@" + parcalar[1] + "@" + a;
                        }
                        sw.WriteLine(satir);
                    }
                }
                File.Delete(path);
                File.Move(geciciDosyaYolu, path);
            }
            catch (Exception e)
            {
                Console.WriteLine("Dosya işlenirken bir hata oluştu:");
                Console.WriteLine(e.Message);
            }
        }
    }
    public class Node  // düğüm nesnemiz 
    {
        public int x;   // x ve y kordinatlarını tutar 
        public int y;
        public Node ileri;

        public Node(int x, int y)
        {
            this.x = x;
            this.y = y;
            this.ileri = null;
        }
    }
    public class Stack  // stack yapımız 
    {
        public Node kok;
        public Node node;
        public Stack()
        {
            this.kok = null;
            this.node = null;
        }
        public void Push(Node yol)  // ekleme metotu 
        {
            if (kok == null)
            {
                kok = yol;
                node = yol;
            }
            else
            {
                if (kok.ileri == null)
                {
                    node = yol;
                    kok.ileri = node;
                }
                else
                {
                    node.ileri = yol;
                    node = yol;
                }
            }

        }
        public Node Pop() // cıkarma metotu 
        {
            if (kok == null)
            {
                return null;
            }
            else
            {
                if (kok == node && node != null)
                {
                    Node temp = node;
                    node = null;
                    kok = null;
                    return temp;
                }
                else
                {
                    Node temp = kok;
                    while (temp.ileri.ileri != null)
                    {
                        temp = temp.ileri;
                    }
                    Node temp1 = node;
                    node = temp;
                    node.ileri = null;
                    return temp1;

                }
            }
        }
        public int Count()  // stack eleman sayısını hesaplama metotmuz 
        {
            int sayac = 1;
            Node temp = kok;
            while (temp.ileri != null)
            {
                temp = temp.ileri;
                sayac++;
            }
            return sayac;
        }
    }
    public class Quueu  // kuyruk yapımız 
    {
        public Node kok;
        public Node node;
        public Quueu()
        {
            kok = null;
            node = null;
        }
        public void Push(Node yol)  // kuyruğa eleman ekleme 
        {
            if (kok == null)
            {
                kok = yol;
                node = yol;
            }
            else
            {
                if (kok.ileri == null)
                {
                    node = yol;
                    kok.ileri = node;
                }
                else
                {
                    node.ileri = yol;
                    node = yol;
                }
            }
        }
        public int Count() // eleman sayısı bulma 
        {
            int sayac = 1;
            Node temp = kok;
            while (temp.ileri != null)
            {
                temp = temp.ileri;
                sayac++;
            }
            return sayac;
        }
        public Node Pop() // eleman cıkarma 
        {
            if (kok == null)
            {
                return null;
            }
            else
            {
                if (kok == node && node != null)
                {
                    Node temp = node;
                    node = null;
                    kok = null;
                    return temp;
                }
                else
                {
                    Node temp = kok;
                    kok = kok.ileri;
                    return temp;
                }
            }
        }
    }
    class Labirentler  // labirent nesnesi 
    {
        public static int[,] maze1 ={                                                                  // labirent matrisimiz 
            { 1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1 } ,
            { 0,0,0,0,0,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,1 } ,       // buradaki 1 ve 0 lara bakılarak duvar ve yollar çiziliyor 
            { 1,1,1,1,0,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,1,1,0,1,1,1,1,1,0,1,0,1,1,1,1,1,0,1 } ,
            { 1,0,0,1,0,1,1,0,1,1,1,1,1,1,0,1,1,1,1,0,1,0,0,0,0,0,0,0,0,1,0,1,0,1,0,0,0,1,0,1 } ,
            { 1,1,0,1,0,1,1,0,1,0,0,0,0,0,0,1,0,0,1,0,1,0,1,1,0,1,1,0,1,1,0,1,0,1,1,0,1,1,0,1 } ,
            { 1,1,0,1,0,0,0,0,1,1,0,1,0,1,0,0,0,1,1,0,0,0,1,0,0,1,1,0,1,1,0,1,0,0,0,0,1,1,0,1 } ,
            { 1,1,0,1,1,1,1,0,1,0,0,1,0,1,0,1,0,0,1,1,1,1,1,0,1,0,1,0,1,0,0,1,0,1,1,1,1,0,0,1 } ,
            { 1,1,0,1,0,0,0,0,1,0,1,0,0,1,0,1,1,1,1,1,0,1,0,0,1,0,1,0,1,0,1,1,0,1,0,1,1,0,1,1 } ,
            { 1,1,0,0,0,1,1,1,1,0,0,1,1,0,0,1,0,0,0,1,0,1,0,1,1,0,0,0,1,0,0,0,0,1,0,0,0,0,1,1 } ,
            { 1,1,0,1,1,1,1,1,1,1,0,1,0,0,1,1,0,1,0,1,0,1,0,0,0,1,0,1,1,1,1,1,1,1,1,1,1,0,1,1 } ,
            { 1,1,0,0,0,1,1,1,1,1,0,1,0,1,0,1,1,1,0,1,0,1,0,1,1,0,0,0,0,1,1,0,0,0,1,1,1,0,1,1 } ,
            { 1,1,1,1,0,1,0,1,0,0,0,1,0,1,0,0,0,1,0,1,0,0,0,1,0,0,1,0,1,0,0,0,1,0,1,0,0,0,1,1 } ,
            { 1,1,0,1,0,1,0,0,0,1,1,0,0,0,1,1,0,1,0,1,1,1,1,1,0,1,0,0,1,0,1,0,1,0,0,0,1,0,1,1 } ,
            { 1,1,0,0,0,1,1,1,1,0,1,0,1,0,0,1,0,1,0,0,0,0,0,0,0,1,1,1,1,0,1,0,1,1,1,1,1,0,1,1 } ,
            { 1,1,1,1,0,0,0,0,1,0,1,0,1,1,0,0,0,0,1,1,1,1,1,1,0,1,0,0,0,1,1,0,0,0,0,0,1,0,1,1 } ,
            { 1,0,0,1,1,1,1,0,1,0,0,0,1,1,0,1,1,0,0,0,0,1,0,1,0,1,0,1,0,0,1,1,1,1,1,0,1,0,1,1 } ,
            { 1,0,1,0,0,0,1,0,1,1,1,0,0,1,0,1,1,1,1,1,0,0,0,1,0,0,1,0,1,0,0,1,0,0,0,0,1,0,1,1 } ,
            { 1,0,1,0,1,1,1,0,0,0,0,1,0,1,1,1,1,1,1,1,1,1,0,1,1,0,0,0,0,1,0,0,0,1,0,1,0,0,1,1 } ,
            { 1,0,0,0,0,0,1,0,1,1,1,1,1,0,0,0,0,0,0,0,1,1,0,0,0,1,1,1,0,0,1,0,1,1,0,1,0,1,0,1 } ,
            { 1,1,1,1,1,0,0,0,1,1,1,0,1,0,1,1,1,1,1,0,1,1,1,0,1,1,1,1,1,1,1,0,1,0,0,1,0,0,0,1 } ,
            { 1,0,0,0,0,0,1,0,0,0,0,0,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,1,0,1,1,1,1,0,1 } ,
            { 1,1,0,1,0,1,1,1,1,1,1,1,1,1,0,1,1,1,0,1,1,1,1,1,0,1,1,1,0,1,1,1,1,0,0,0,0,0,1,1 } ,
            { 1,0,1,0,0,0,0,0,1,1,1,1,1,1,0,0,0,1,0,0,1,0,1,0,0,0,0,1,0,0,0,0,0,1,1,1,1,1,0,0 } ,
            { 1,0,0,0,1,1,1,0,0,0,0,0,1,0,0,1,0,0,1,0,1,0,0,0,1,1,0,0,1,1,1,1,0,0,0,0,0,0,0,1 } ,
            { 1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1 }
        };      
    }
}