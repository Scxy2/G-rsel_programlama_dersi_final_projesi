﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Reflection.Emit;

namespace Maze_Runner
{
    public partial class Sıralama : Form
    {
        public Sıralama()
        {
            InitializeComponent();
        }

        private void Geri(object sender, EventArgs e)  // geri butonu tıklanma eventi 
        {
            this.Close();
        }

        private void Sıralama_Load(object sender, EventArgs e)  // sıralam formunun load kısmı 
        {
            listView1.Columns.Add("Kullanıcı", 250);   // listview e sutun eklenir 
            listView1.Columns.Add("Puan", 150);    // listview e sutun eklenir 
            Yaz();
        }
        private void Yaz()   // bu metotu kullanıcılar.txt dosyaındaki verileri listview'e ıtem olarak verir
        {
            List<string[]> list = new List<string[]>();  // list nesnesi 
            string path = "Kullanıcılar.txt";   // kullanıcılar.txt yolu 
            using (StreamReader sr = new StreamReader(path))   // okuma nesnesi 
            {
                string line;
                while ((line = sr.ReadLine()) != null)  //  satırları gezme 
                {
                    string[] a = line.Split("@");  // satırları @ göre bölme 
                    string[] b = new string[2];  // kullanıcıları ve puanını almak için başkabir string dizisi nesnesi 
                    b[0] = a[0]; //b string dizisi nesnesine kullanıcıları atama 
                    if (a[2].Length > 3)
                    { 
                        b[1] = a[2];   // b string dizisine paunları atama 
                    }
                    else
                    {
                        b[1] = "0";   // puanı girilmemiş olanlara 0 atama 
                    }
                    list.Add(b);   // diziyi liste atama 
                }
            }
            List_yaz(Sort_list(list));  //listview item oluşturma  işlemi ve list sort işlemi              (aşağıda metotlar tanımlanmış)

            if (listView1.Items.Count > 0)   //1.lik  cercevesi 
            {
                System.Drawing.Image ad;
                System.Drawing.Image img = System.Drawing.Image.FromFile("1.jpg");
                ad = new Bitmap(img, pictureBox4.Width, pictureBox4.Height); 
                pictureBox4.Image = ad;
                pictureBox4.Visible = true;
                label1.Text=listView1.Items[0].Text;
                label1.Location=new Point(520-label1.Size.Width/2,73);
                label1.Visible = true;
            }
            if (listView1.Items.Count > 1) //2.lik cercevesi 
            {
                System.Drawing.Image ad;
                System.Drawing.Image img = System.Drawing.Image.FromFile("2.jpg");
                ad = new Bitmap(img, pictureBox5.Width, pictureBox5.Height);
                pictureBox5.Image = ad;
                pictureBox5.Visible = true;
                label2.Text = listView1.Items[1].Text;
                label2.Location = new Point(520 - label1.Size.Width/2, 153);
                label2.Visible = true;
            }
            if (listView1.Items.Count > 2) //3.lük cercevesi 
            {
                System.Drawing.Image ad;
                System.Drawing.Image img = System.Drawing.Image.FromFile("3.jpg");
                ad = new Bitmap(img, pictureBox6.Width, pictureBox6.Height);
                pictureBox6.Image = ad;
                pictureBox6.Visible = true;
                label3.Text = listView1.Items[2].Text;
                label3.Location = new Point(520 - label1.Size.Width / 2, 233);
                label3.Visible = true;
            }

        }
        private List<string[]> Sort_list(List<string[]> list)  // list sort işlemi ( pubble sort) algoritması 
        {
            List<string[]> k = new List<string[]>();

            while (list.Count > 0)
            {
                if (list.Count == 1)
                {
                    k.Add(list[0]);
                    list.RemoveAt(0);
                }
                else
                {
                    string[] temp = list[0];
                    for (int i = 1; i < list.Count; i++)
                    {
                        if (int.Parse(temp[1]) < int.Parse(list[i][1]))
                        {
                            temp = list[i];
                        }
                    }
                    k.Add(temp);
                    list.Remove(temp);
                }

            }
            return k;
        }
        private void List_yaz(List<string[]> list)   // Listview'e item oluşturma ve listview controlune atama yapan metot 
        {
            for (int i = 0; i < list.Count; i++)
            {
                string[] a = list[i];
                ListViewItem lv = new ListViewItem(a);
                listView1.Items.Add(lv);
            }
        }

    }
}
