﻿namespace Maze_Runner
{
    partial class MazeRunner
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            button1 = new Button();
            button3 = new Button();
            button2 = new Button();
            pictureBox1 = new PictureBox();
            button4 = new Button();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // button1
            // 
            button1.Font = new Font("Segoe UI", 24F, FontStyle.Regular, GraphicsUnit.Point, 162);
            button1.ForeColor = Color.FromArgb(0, 192, 0);
            button1.Location = new Point(475, 443);
            button1.Name = "button1";
            button1.Size = new Size(250, 70);
            button1.TabIndex = 0;
            button1.Text = "Giriş";
            button1.UseVisualStyleBackColor = true;
            button1.Click += Giris_yap;
            // 
            // button3
            // 
            button3.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 162);
            button3.ForeColor = Color.FromArgb(0, 192, 0);
            button3.Location = new Point(475, 594);
            button3.Name = "button3";
            button3.Size = new Size(122, 36);
            button3.TabIndex = 2;
            button3.Text = "Masaüstü";
            button3.UseVisualStyleBackColor = true;
            button3.Click += Masaustu_don;
            // 
            // button2
            // 
            button2.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 162);
            button2.ForeColor = Color.FromArgb(0, 192, 0);
            button2.Location = new Point(603, 594);
            button2.Name = "button2";
            button2.Size = new Size(122, 36);
            button2.TabIndex = 2;
            button2.Text = "Kayıt ol";
            button2.UseVisualStyleBackColor = true;
            button2.Click += Kayıt_ol;
            // 
            // pictureBox1
            // 
            pictureBox1.Location = new Point(263, 12);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(693, 425);
            pictureBox1.TabIndex = 3;
            pictureBox1.TabStop = false;
            // 
            // button4
            // 
            button4.Font = new Font("Segoe UI", 24F, FontStyle.Regular, GraphicsUnit.Point, 162);
            button4.ForeColor = Color.FromArgb(0, 192, 0);
            button4.Location = new Point(475, 519);
            button4.Name = "button4";
            button4.Size = new Size(250, 69);
            button4.TabIndex = 4;
            button4.Text = "Sıralama";
            button4.UseVisualStyleBackColor = true;
            button4.Click += Siralamayi_gor;
            // 
            // MazeRunner
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.ActiveCaptionText;
            ClientSize = new Size(1200, 850);
            Controls.Add(button4);
            Controls.Add(pictureBox1);
            Controls.Add(button2);
            Controls.Add(button3);
            Controls.Add(button1);
            FormBorderStyle = FormBorderStyle.None;
            Name = "MazeRunner";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "MazeRunner";
            Load += MazeRunner_Load;
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private Button button1;
        private Button button3;
        private Button button2;
        private PictureBox pictureBox1;
        private Button button4;
    }
}
