using System;
using System.Runtime.CompilerServices;
using System.Security.Cryptography.X509Certificates;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.Tab;

namespace Maze_Runner
{
    public partial class MazeRunner : Form
    {
        public MazeRunner()
        {
            InitializeComponent();
        }

        private void MazeRunner_Load(object sender, EventArgs e)
        {
            this.StartPosition = FormStartPosition.CenterScreen;   // Ana form �zellikleri ayarlama 
            this.Size = new Size(1200, 850);
            string imagePath = @"Ana_resim.png";   // pictureboxa resim koyma
            System.Drawing.Image img = System.Drawing.Image.FromFile(imagePath);
            System.Drawing.Image a = new Bitmap(img, pictureBox1.Width, pictureBox1.Height);
            pictureBox1.Image = a;
            Lav_ani();  // lav animation 
        }
        private void Giris_yap(object sender, EventArgs e)    // giri� butonuna t�klama eventi 
        {
            Giri� log = new Giri�();
            log.FormClosing += Giri�_FormClosing;
            log.Show();
            this.Hide();
        }
        public async void Lav_ani()  // lav animasyon 
        {
            for (int i = 0; i < 24; i++)
            {
                Lav_picturebox a1 = new Lav_picturebox(i * 50, 800);
                this.Controls.Add(a1);
                await Task.Delay(750);
            }
        }

        private void Masaustu_don(object sender, EventArgs e)   // program� sonland�rma 
        {
            Dispose();
        }
        private void Giri�_FormClosing(object sender, FormClosingEventArgs e)  //  burada giri� formunun kapatma eventini tan�ml�yoruz 
        {
            this.Show();
        }
        private void Kay�t_Form_FormClosing(object sender, FormClosingEventArgs e)   // ayn� �ekil kay�t formununda kapatma eventini tan�ml�yoruz 
        {
            this.Show();
        }
        public class Lav_picturebox : PictureBox   //lav picture box 
        {
            private string[] Lavlar = { "lav1.png", "lav2.png", "lav3.png", "lav4.png", "lav5.png", "lav6.png", "lav7.png", "lav8.png" };  // resimleri cekmek i�in bir dizin tan�mlad�
            private int en = 50;
            int index = 0;
            private int boy = 50;
            private System.Windows.Forms.Timer timer1;  //timer nesnemiz // olu�turulan her pictureboxun arka plan�n�n timer ile animasyon havas� kat�yoruz
            private System.Drawing.Image[] Lavlar1;
            public Lav_picturebox(int x, int y)   // lac picturebox  constructer�m�z 
            {
                timer1 = new System.Windows.Forms.Timer();
                timer1.Interval = 300;              //
                timer1.Tick += Timer1_Tick;        //     gerekli tan�mlamalar 
                Bounds = new Rectangle(x, y, 50, 50);  //
                LoadImages();
                timer1.Start();
            }

            private void LoadImages()  //oyun dosyalar�ndan resimleri cekme  ve resimlerin boyutlar�n�n ayarlamak i�in olu�turulmu� metot 
            {
                Lavlar1 = new System.Drawing.Image[Lavlar.Length];
                for (int i = 0; i < Lavlar.Length; i++)
                {
                    string imagePath = @"Lav_animation\" + Lavlar[i];
                    System.Drawing.Image img = System.Drawing.Image.FromFile(imagePath);
                    Lavlar1[i] = new Bitmap(img, en, boy);
                }
            }
            private void Timer1_Tick(object sender, EventArgs e)  // timer tetik metotu 
            {
                ChangeBackgroundImage();
                timer1.Start();

            }
            private void ChangeBackgroundImage()   // pictureboxun arka plan resmini olu�turulan Image dizininden s�ras�yla verme 
            {
                index = (index + 1) % Lavlar.Length;
                Image = Lavlar1[index];
                Refresh();
            }
        }

        private void Kay�t_ol(object sender, EventArgs e)   // kay�t butonunn t�klanma eventi 
        {
            Kay�t_Form kyt = new Kay�t_Form();
            kyt.FormClosing += Kay�t_Form_FormClosing;
            kyt.Show();
            this.Hide();
        }

        private void Siralamayi_gor(object sender, EventArgs e)  // s�ralama metotunun t�klanma eventi
        {
            S�ralama sr = new S�ralama();
            sr.FormClosing += Siralama_FormClosing;
            sr.Show();
            this.Hide();
        }
        private void Siralama_FormClosing(object sender, FormClosingEventArgs e)   // s�ralama formunun kapanma eventi 
        {
            this.Show();               
        }
    }
}
