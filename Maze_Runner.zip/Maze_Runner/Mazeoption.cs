﻿using NAudio.Wave;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Maze_Runner
{
    public partial class Mazeoption : Form
    {
        public string Ses_yolu;  // ses yolları 
        public string Kullanıcı; // kullanıcı 
        public Mazeoption(string klc)
        {
            InitializeComponent();
            // Her bir groupbox'taki varsayılan olarak seçili checkbox'u belirle
            SetInitialCheckboxSelection(groupBox1);
            SetInitialCheckboxSelection(groupBox2);
            SetInitialCheckboxSelection(groupBox3);

            // Her bir groupbox'taki checkbox'ların olaylarını dinle
            SetCheckboxEventHandlers(groupBox1);
            SetCheckboxEventHandlers(groupBox2);
            SetCheckboxEventHandlers(groupBox3);
            Ses_yolu = @"Lav_sesi\Lav_sesi1.mp3";
            Kullanıcı = klc;
        }


        private void Geri(object sender, EventArgs e)  // geri butonunun tıklanme eventi 
        {
            this.Close();
        }
        private void Basla(object sender, EventArgs e)  // basla butonunun tıklanme eventi 
        {
            Form lab = new Maze(Lav_algoritma_secimi(groupBox1), Lav_hızı(groupBox2), Kat_sayı_hesapla(), trackBar1.Value, Ses_yolu, Kullanıcı);  // Maze formu burada yapılır 
            lab.FormClosing += Maze_FormClosing;  
            lab.Show();  
            this.Hide();
        }
        private void Maze_FormClosing(object sender, FormClosingEventArgs e)  // maze formunu kapatma eventi 
        {
            this.Show();
        }
        private void SetInitialCheckboxSelection(GroupBox groupBox)  // checkkboxlara varsayılan olan ilk checkboxu true yapma 
        {
            bool firstChecked = false;    // flag değer 
            foreach (Control control in groupBox.Controls)  
            {
                if (control is CheckBox checkBox) //control nesnesindeki ilk indexdeki checkedbox true yapar 
                {
                    checkBox.Checked = false;
                    if (!firstChecked)
                    {
                        checkBox.Checked = true;
                        firstChecked = true;
                    }
                }
            }
        }



        private void SetCheckboxEventHandlers(GroupBox groupBox)
        {
            foreach (Control control in groupBox.Controls)
            {
                if (control is CheckBox checkBox)
                {
                    checkBox.CheckedChanged += (sender, e) => Checkbox_CheckedChanged(sender, groupBox);
                }
            }
        }
        private void Checkbox_CheckedChanged(object sender, GroupBox groupBox)
        {
            CheckBox clickedCheckbox = sender as CheckBox;

            foreach (Control control in groupBox.Controls)
            {
                if (control is CheckBox checkbox && checkbox != clickedCheckbox)
                {
                    checkbox.Checked = false;
                }
            }
        }
        public int Lav_algoritma_secimi(GroupBox groupBox) // lav algoritmasının checkboxlardan ceken metot 
        {
            foreach (Control control in groupBox.Controls)
            {
                if (control is CheckBox checkBox)
                {
                    if (checkBox.Checked == true)
                    {
                        return (int)checkBox.TabIndex;
                    }
                }
            }
            return -1;
        }
        public int Lav_hızı(GroupBox groupBox)  // lav hızını checkboxlardan ceken metot 
        {
            foreach (Control control in groupBox.Controls)
            {
                if (control is CheckBox checkBox)
                {
                    if (checkBox.Checked == true)
                    {
                        if ((int)checkBox.TabIndex == 0)
                        {
                            return 700;
                        }
                        else if ((int)checkBox.TabIndex == 1)
                        {
                            return 650;
                        }
                        else if ((int)checkBox.TabIndex == 2)
                        {
                            return 600;
                        }
                        else if ((int)checkBox.TabIndex == 3)
                        {
                            return 550;
                        }
                    }
                }
            }
            return -1;
        }

        private void checkBox2_CheckedChanged(object sender, EventArgs e)    ////////////////// chechboxlar değiştiğinde ilgili yerlerin değişmesini sağlayan metotlar 
        {
            if (checkBox2.Checked == true)
            {
                button3.Text = "10";
                button6.Text = $"Lav algoritması----->{checkBox2.Text}";
                button9.Text = (int.Parse(button3.Text) + int.Parse(button4.Text) + int.Parse(button5.Text)).ToString();

            }
            else if (checkBox2.Checked == false && checkBox1.Checked == false)
            {
                button3.Text = "0";
                button6.Text = $"Lav algoritması----->                ";
                button9.Text = (int.Parse(button3.Text) + int.Parse(button4.Text) + int.Parse(button5.Text)).ToString();
            }
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox1.Checked == true)
            {
                button3.Text = "30";
                button6.Text = $"Lav algoritması----->{checkBox1.Text}";
                button9.Text = (int.Parse(button3.Text) + int.Parse(button4.Text) + int.Parse(button5.Text)).ToString();
            }
            else if (checkBox2.Checked == false && checkBox1.Checked == false)
            {
                button3.Text = "0";
                button6.Text = $"Lav algoritması----->     ";
                button9.Text = (int.Parse(button3.Text) + int.Parse(button4.Text) + int.Parse(button5.Text)).ToString();
            }
        }

        private void checkBox6_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox6.Checked == true)
            {
                button4.Text = "10";
                button7.Text = $"Lav Hızı----->{checkBox6.Text}";
                button9.Text = (int.Parse(button3.Text) + int.Parse(button4.Text) + int.Parse(button5.Text)).ToString();
            }
            else if (checkBox4.Checked == false && checkBox6.Checked == false && checkBox5.Checked == false && checkBox3.Checked == false)
            {
                button4.Text = "0";
                button7.Text = $"Lav Hızı----->    ";
                button9.Text = (int.Parse(button3.Text) + int.Parse(button4.Text) + int.Parse(button5.Text)).ToString();
            }
        }

        private void checkBox4_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox4.Checked == true)
            {
                button4.Text = "20";
                button7.Text = $"Lav Hızı----->{checkBox4.Text}";
                button9.Text = (int.Parse(button3.Text) + int.Parse(button4.Text) + int.Parse(button5.Text)).ToString();
            }
            else if (checkBox4.Checked == false && checkBox6.Checked == false && checkBox5.Checked == false && checkBox3.Checked == false)
            {
                button7.Text = $"Lav Hızı----->     ";
                button4.Text = "0";
                button9.Text = (int.Parse(button3.Text) + int.Parse(button4.Text) + int.Parse(button5.Text)).ToString();
            }
        }

        private void checkBox5_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox5.Checked == true)
            {
                button4.Text = "30";
                button7.Text = $"Lav Hızı----->{checkBox5.Text}";
                button9.Text = (int.Parse(button3.Text) + int.Parse(button4.Text) + int.Parse(button5.Text)).ToString();
            }
            else if (checkBox4.Checked == false && checkBox6.Checked == false && checkBox5.Checked == false && checkBox3.Checked == false)
            {
                button4.Text = "0";
                button7.Text = $"Lav Hızı----->     ";
                button9.Text = (int.Parse(button3.Text) + int.Parse(button4.Text) + int.Parse(button5.Text)).ToString();
            }
        }

        private void checkBox3_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox3.Checked == true)
            {
                button4.Text = "40";
                button7.Text = $"Lav Hızı----->{checkBox3.Text}";
                button9.Text = (int.Parse(button3.Text) + int.Parse(button4.Text) + int.Parse(button5.Text)).ToString();
            }
            else if (checkBox4.Checked == false && checkBox6.Checked == false && checkBox5.Checked == false && checkBox3.Checked == false)
            {
                button4.Text = "0";
                button7.Text = $"Lav Hızı----->     ";
                button9.Text = (int.Parse(button3.Text) + int.Parse(button4.Text) + int.Parse(button5.Text)).ToString();
            }
        }
        private void checkBox8_CheckedChanged(object sender, EventArgs e)   
        {
            if (checkBox8.Checked == true)
            {
                button5.Text = "10";
                button8.Text = $"Labirent----->{checkBox8.Text}";
                button9.Text = (int.Parse(button3.Text) + int.Parse(button4.Text) + int.Parse(button5.Text)).ToString();
            }
            else if (checkBox8.Checked == false && checkBox7.Checked == false)
            {
                button5.Text = "0";
                button8.Text = $"Labirent----->";
                button9.Text = (int.Parse(button3.Text) + int.Parse(button4.Text) + int.Parse(button5.Text)).ToString();
            }
        }
        private void checkBox7_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox7.Checked == true)
            {
                MessageBox.Show("Çok yakında!!!");
                button8.Text = $"Labirent----->";
            }
            button8.Text = $"Labirent----->";

        }
        public int Kat_sayı_hesapla()  // Kat sayı hesaplayıcı 
        {
            int a = int.Parse(button4.Text);
            int b = int.Parse(button5.Text);
            int c = int.Parse(button3.Text);
            return a + b + c;
        }
        private void Ses_sec(object sender, EventArgs e)   // butonlara tıklandığında hangi ses dosyasını belirleyen metotlar 
        {
            Ses_yolu = @"Lav_sesi\Lav_sesi1.mp3";
            MessageBox.Show("Ses başarıyla değiştirildi");
        }
        private void button11_Click(object sender, EventArgs e)  
        {
            Ses_yolu = @"Lav_sesi\Lav_sesi2.mp3";
            MessageBox.Show("Ses başarıyla değiştirildi");
        }
    }
}

